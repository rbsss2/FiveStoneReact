import GlobalStyle from "./assets/style/GlobalStyle";
import FiveStone from "./component/FiveStone";

function App() {
  return (
    <div>
      <GlobalStyle />

      <FiveStone />
    </div>
  );
}

export default App;
